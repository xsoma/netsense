#include "globals.hpp"

namespace CheatGVars {
	float OFOV;	
	
	int SWidth;
	int SHeight;
	
	int SWidthHalf;
	int SHeightHalf;

	bool SlowWalking;

	bool UpdateNightMode;

	LPVOID lpvReserved;
}