#pragma once
#include <vector>

#include "visuals/visuals.hpp"
#include "misc/misc.hpp"
#include "prediction/prediction.hpp"
#include "legitbot/aimbot.hpp"
#include "legitbot/backtrack.hpp"
#include "legitbot/weapon_groups.hpp"
#include "changer/changer.hpp"
#include "changer/parser.hpp"
#include "changer/knife_fix.hpp"