#include "../../valve_sdk/sdk.hpp"
#include "../../valve_sdk/csgostructs.hpp"

namespace NoVisualRecoil {
	void OverrideView(CViewSetup* pSetup);
};