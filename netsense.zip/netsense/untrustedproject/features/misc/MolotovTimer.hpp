#pragma once
#include "../../valve_sdk/sdk.hpp"
#include "../../valve_sdk/csgostructs.hpp"


class MolotovTimer {
public:
	void Draw();
};


extern MolotovTimer g_MolotovTimer;