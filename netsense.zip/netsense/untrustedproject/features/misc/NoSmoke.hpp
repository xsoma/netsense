#pragma once

namespace NoSmoke {
	void OnFrameStageNotify();
}