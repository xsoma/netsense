
namespace NightMode {
	void EndScene();
};