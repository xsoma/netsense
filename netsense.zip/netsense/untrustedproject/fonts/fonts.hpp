#pragma once
namespace Fonts {
	#include "droid.hpp"
	#include "cousine.hpp"
	#include "profont.hpp"
	#include "visitor2.hpp"
	#include "ubuntumono.h"
    #include "AkrobatBold.h"
}