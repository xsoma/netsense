#pragma once
#include <Windows.h>

namespace CheatGVars {
	extern float OFOV;
	extern int SWidth;
	extern int SHeight;
	extern int SWidthHalf;
	extern int SHeightHalf;
	extern bool SlowWalking;
	extern bool UpdateNightMode;
	extern LPVOID lpvReserved;
}